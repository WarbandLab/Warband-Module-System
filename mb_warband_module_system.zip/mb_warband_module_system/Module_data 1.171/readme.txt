Mount&Blade Warband Module "Data" Files 

You can add new flora kinds, skyboxes and edit the ground types with this phyton files.
You can edit and regenerate;
 skyboxes.txt
 flora_kinds.txt
 ground_specs.txt
files and put them on your module's Data folder.
More information about the usage & limitations can be found on the *.py files.

www.taleworlds.com