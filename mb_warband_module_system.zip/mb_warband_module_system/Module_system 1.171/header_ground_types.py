ground_gray_stone = 0
ground_brown_stone = 1
ground_turf = 2
ground_steppe = 3
ground_snow = 4
ground_earth = 5
ground_desert = 6
ground_forest = 7
ground_pebbles = 8
ground_village = 9
ground_path = 10


