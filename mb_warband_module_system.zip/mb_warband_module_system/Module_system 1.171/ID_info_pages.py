ip_morale = 0
ip_economy = 1
ip_courtship = 2
ip_politics = 3
ip_character_backgrounds = 4
ip_military_campaigns = 5


