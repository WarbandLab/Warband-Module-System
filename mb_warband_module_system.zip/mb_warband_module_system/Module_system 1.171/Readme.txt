Mount&Blade Module System

For getting documentation and the latest version of the module system check out:

www.taleworlds.com/mb_module_system.html

